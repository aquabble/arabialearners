# Arabic Study Combined

## Usage

- Install deps: `npm install`
- Run dev server: `npm run dev`

### Auth modes
- Default: Google OAuth (local) in App.jsx
- Firebase: rename App.firebase.jsx -> App.jsx and fill .env with your Firebase config
