# Arabic Study — Combined Bundle
Includes modular app, Firebase scaffold, and auto-upload.

## Setup
1) npm i
2) npm run dev (local OAuth) OR:
   - npm i firebase
   - copy .env.sample → .env with Firebase config
   - rename src/App.firebase.jsx → src/App.jsx
   - npm run dev
